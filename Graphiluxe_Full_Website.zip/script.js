function filterGallery() {
  const input = document.getElementById('searchInput').value.toLowerCase();
  const items = document.querySelectorAll('.gallery .item');
  items.forEach(item => {
    const tags = item.getAttribute('data-tags').toLowerCase();
    item.style.display = tags.includes(input) ? 'block' : 'none';
  });
}

function loadMore() {
  const hiddenItems = document.querySelectorAll('.gallery .item.hidden');
  hiddenItems.forEach((el, index) => {
    if (index < 2) el.classList.remove('hidden');
  });
}
